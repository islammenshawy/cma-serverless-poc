# cma-serverless-poc
App to test serverless architecture
